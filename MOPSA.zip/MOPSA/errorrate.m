function [err] = errorrate(score,bsplit,y)
   cls=ones(length(score),1);
   cls((score<bsplit))=2;
   cp=classperf(y,cls,'Positive',2,'Negative',1);
   err=cp.LastErrorRate; 

function err=ldaholdout(sample,k,c,perm)
%% ---------- scale UV ------------
[k,IX] = sort(k);
X=sample(IX,:);
%% ---------- LDA permutation------------
err=zeros(perm,1);   
fprintf(' The LDA is modeling.\n');
fprintf('  Percentage(test samples): %g\n\n',c);
for permu=1:perm
%---------- choose samples for trainning ------------
	[train, test] = crossvalind('HoldOut', k, c);
	[C,error,P,logp,coeff] = classify(X(test,:),X(train,:),k(train),...
                                          'diaglinear');
	co=coeff(1,2);
	samplescore=X(test,:)*co.linear+co.const;
	C(samplescore<0)=2;
	C(samplescore>=0)=1;
	cp=classperf(k(test),C,'Positive', 2, 'Negative', 1); 
	errrate=cp.ErrorRate;
%---------- compute the error rate ------------
	err(permu)=errrate;
end
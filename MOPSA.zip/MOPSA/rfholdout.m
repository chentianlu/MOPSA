function err = rfholdout(sample,k,treenum)
fprintf(' The RF is modeling.\n');
%% ----------- Random Forest ---------- %%
b = TreeBagger(treenum,sample,k,'oobvarimp','on','minleaf',10);
%% ----------- error rate curve ---------- %%
err=oobError(b);

function varargout = MOPSA(varargin)
%MOPSA M-file for MOPSA.fig
%      MOPSA, by itself, creates a new MOPSA or raises the existing
%      singleton*.
%
%      H = MOPSA returns the handle to a new MOPSA or the handle to
%      the existing singleton*.
%
%      MOPSA('Property','Value',...) creates a new MOPSA using the
%      given property value pairs. Unrecognized properties are passed via
%      varargin to test_OpeningFcn.  This calling syntax produces a
%      warning when there is an existing singleton*.
%
%      MOPSA('CALLBACK') and MOPSA('CALLBACK',hObject,...) call the
%      local function named CALLBACK in MOPSA.M with the given input
%      arguments.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help MOPSA

% Last Modified by GUIDE v2.5 01-Nov-2010 18:34:27

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @MOPSA_OpeningFcn, ...
                   'gui_OutputFcn',  @MOPSA_OutputFcn, ...
                   'gui_LayoutFcn',  [], ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
   gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before MOPSA is made visible.
function MOPSA_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   unrecognized PropertyName/PropertyValue pairs from the
%            command line (see VARARGIN)

% Choose default command line output for MOPSA
handles.output = hObject;

% Update handles structure
guidata(hObject, handles);

% UIWAIT makes MOPSA wait for user response (see UIRESUME)
% uiwait(handles.figure1);
% --- Outputs from this function are returned to the command line.
function varargout = MOPSA_OutputFcn(hObject, eventdata, handles)
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;
% --- Executes on button press in import.
function import_Callback(hObject, eventdata, handles)
% hObject    handle to import (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global X0 k0 path sampleindex varindex;
[FileSTD,PathSTD] = uigetfile('*.xls','Select the EXCEL-file(2003)');
path=PathSTD;
if(FileSTD==0)
    error('No xls file is selected!');
else
%% ---------- data ------------ %%
    traindata = xlsread([PathSTD FileSTD]);    
    X0=traindata(3:end,2:end)';
    k0=traindata(2,2:end)';
    sampleindex=traindata(1,2:end)';
    varindex=traindata(3:end,1);
    set(handles.screen,'Enable','on');
    set(handles.screen,'String',[PathSTD FileSTD]);
    set(handles.setting,'Enable','on');
end
% --- Executes on button press in setting.
function setting_Callback(hObject, eventdata, handles)
% hObject    handle to setting (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
set(handles.UV,'Enable','on');
set(handles.par,'Enable','on');
set(handles.Centering,'Enable','on');
set(handles.plsprocess,'Enable','on');
set(handles.svmprocess,'Enable','on');
set(handles.ldaprocess,'Enable','on');
set(handles.rfprocess,'Enable','on');
set(handles.cv,'Enable','on');
set(handles.treenum,'Enable','on');
set(handles.performance,'Enable','on');
set(handles.saveset,'Enable','on');
set(handles.defaultset,'Enable','on');
global pre ifflag cvfold treenum;
pre=1;ifflag=[0 0 0 0];cvfold=10;treenum=200;
% --- Executes on button press in performance.
function performance_Callback(hObject, eventdata, handles)
% hObject    handle to performance (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
set(handles.repeatholdout,'Enable','on');
set(handles.permutation,'Enable','on');
set(handles.rocprocess,'Enable','on');
global ifholdout ifperm ifroc c c1 reptime reptime1; 
ifholdout=0;ifperm=0;ifroc=0;c=10;c1=10;reptime=100;reptime1=100;
% --- Executes on button press in Run.
function Run_Callback(hObject, eventdata, handles)
% hObject    handle to Run (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
set(MOPSA,'visible','off');
processing;
global X0 k0 path;
global pre ifflag cvfold treenum;
global ifholdout ifperm ifroc c c1 reptime reptime1; 
global samplescore varrank mlerr mlerrs mlroc mlarea;
sample=MLpretreat(pre,X0);
plsscore=zeros(size(sample,1),1);svmscore=plsscore;ldascore=plsscore;
rfscore=plsscore;
plsrank=zeros(size(sample,2),1);svmrank=plsrank;ldarank=plsrank;
rfrank=plsrank;
if(ifflag(1)==1)
    [plsscore,plsrank] = plsprocess(sample,k0,cvfold);    
end
if(ifflag(2)==1)
    [svmscore,svmrank] = svmprocess(sample,k0,cvfold);
end
if(ifflag(3)==1)
    [ldascore,ldarank] = ldaprocess(sample,k0,cvfold);
end
if(ifflag(4)==1)
    [rfscore,rfrank,rferror] = rfprocess1(sample,k0,treenum);
end
samplescore=[plsscore svmscore ldascore rfscore];
varrank=[plsrank svmrank ldarank rfrank];
figure('Name','Sample Score','NumberTitle','off')
plotcls(ifflag,samplescore,k0);
figname=[path 'Sample Score.tiff'];
print(1,'-dtiff',figname);

plserr=zeros(reptime,1);svmerr=plserr;ldaerr=plserr;
rferr=plserr;
plserrs=zeros(reptime1,1);svmerrs=plserrs;ldaerrs=plserrs;
rferrs=plserrs;
if(ifholdout==1)
    if(ifflag(1)==1)
        plserr = plsholdout(sample,k0,c/100,reptime);
    end
    if(ifflag(2)==1)
        svmerr = svmholdout(sample,k0,c/100,reptime);
    end
    if(ifflag(3)==1)
        ldaerr = ldaholdout(sample,k0,c/100,reptime);
    end
    if(ifflag(4)==1)
        rferr = rferror(end-reptime:end);
    end
    mlerr=[plserr svmerr ldaerr rferr];
    figure('Name','Hold-out repeat error rate','NumberTitle','off')
    ploterr(ifflag,mlerr);
    figname=[path 'Hold-out error.tiff'];
    print(2,'-dtiff',figname);
end
if(ifperm==1)
    k=k0(randperm(length(k0))); %swap 
    if(ifflag(1)==1)
        plserrs = plsholdout(sample,k,c1/100,reptime1);
    end
    if(ifflag(2)==1)
        svmerrs = svmholdout(sample,k,c1/100,reptime1);
    end
    if(ifflag(3)==1)
        ldaerrs = ldaholdout(sample,k,c1/100,reptime1);
    end
    if(ifflag(4)==1)
        errs = rfholdout(sample,k,c1/100,reptime1);
        rferrs=errs(end-reptime1:end);
    end
    mlerrs=[plserrs svmerrs ldaerrs rferrs];
    figure('Name','Permutation error rate','NumberTitle','off')
    ploterr(ifflag,mlerrs);
    figname=[path 'Permutation.tiff'];
    print(3,'-dtiff',figname);
end
plsroc=zeros(1021,2);svmroc=plsroc;ldaroc=plsroc;
rfroc=plsroc;plsarea=0;svmarea=0;ldaarea=0;rfarea=0;
if(ifroc==1)
    if(ifflag(1)==1)
        [plsroc,plsarea] = rocroc(plsscore,k0);
    end
    if(ifflag(2)==1)
        [svmroc,svmarea] = rocroc(svmscore,k0);
    end
    if(ifflag(3)==1)
        [ldaroc,ldaarea] = rocroc(ldascore,k0);
    end
    if(ifflag(4)==1)
        [rfroc,rfarea] = rocroc(rfscore,k0);
    end
    mlroc=[plsroc svmroc ldaroc rfroc];
    mlarea=[plsarea svmarea ldaarea rfarea];
    figure('Name','ROC','NumberTitle','off')
    plotroc(ifflag,mlroc,mlarea);
    figname=[path 'ROC.tiff'];
    print(4,'-dtiff',figname);
end
close(processing);
set(MOPSA,'visible','on');
set(handles.Export,'Enable','on');
% --- Executes on button press in Export.
function Export_Callback(hObject, eventdata, handles)
% hObject    handle to Export (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global path ifflag sampleindex varindex;
global ifholdout ifperm samplescore varrank mlerr mlerrs;
ifplot=find(ifflag);
mlstr=[{'PLS'} {'SVM'} {'LDA'} {'RF'}];
tabletitle=[{'sample index'} mlstr(ifplot)];
scoretable=[sampleindex samplescore(:,ifplot)];
scorefinal=[tabletitle;num2cell(scoretable)];
filename=[path 'scoretable.xls'];
xlswrite(filename,scorefinal);

tabletitle=[{'variable index'} mlstr(ifplot)];
vartable=[varindex varrank(:,ifplot)];
varfinal=[tabletitle;num2cell(vartable)];
filename=[path 'varrank.xls'];
xlswrite(filename,varfinal);
if(ifholdout)
    errfinal=[mlstr(ifplot);num2cell(mlerr(:,ifplot))];
    filename=[path 'holdout error.xls'];
    xlswrite(filename,errfinal);
end
if(ifperm)
    errsfinal=[mlstr(ifplot);num2cell(mlerrs(:,ifplot))];
    filename=[path 'permutation.xls'];
    xlswrite(filename,errsfinal);
end
msgbox('The results is saved as xls files in the same folder with import��'...
        ,'Export success');
% --- Executes on button press in Help.
function Help_Callback(hObject, eventdata, handles)
% hObject    handle to Help (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
mopsahelp;

% --- Executes on button press in rocprocess.
function rocprocess_Callback(hObject, eventdata, handles)
% hObject    handle to rocprocess (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of rocprocess
global ifroc
if (get(hObject,'Value') == get(hObject,'Max'))
    % then radio button is selected-take approriate action
    ifroc=1;
else
    % radio button is not selected-take approriate action
    ifroc=0;
end
% --- Executes during object creation, after setting all properties.
function treenum_CreateFcn(hObject, eventdata, handles)
% hObject    handle to treenum (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
% --- Executes during object creation, after setting all properties.
function cv_CreateFcn(hObject, eventdata, handles)
% hObject    handle to cv (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
% --- Executes during object creation, after setting all properties.
function reptime1_CreateFcn(hObject, eventdata, handles)
% hObject    handle to reptime1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
% --- Executes during object creation, after setting all properties.
function c1_CreateFcn(hObject, eventdata, handles)
% hObject    handle to c1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
% --- Executes during object creation, after setting all properties.
function c_CreateFcn(hObject, eventdata, handles)
% hObject    handle to c (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
% --- Executes during object creation, after setting all properties.
function reptime_CreateFcn(hObject, eventdata, handles)
% hObject    handle to reptime (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
% --- Executes during object creation, after setting all properties.
function screen_CreateFcn(hObject, eventdata, handles)
% hObject    handle to screen (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
% --- Executes on button press in repeatholdout.
function repeatholdout_Callback(hObject, eventdata, handles)
% hObject    handle to repeatholdout (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global ifholdout
if (get(hObject,'Value') == get(hObject,'Max'))
    % then radio button is selected-take approriate action
    ifholdout=1;
    set(handles.c,'Enable','on');
    set(handles.reptime,'Enable','on');
else
    % radio button is not selected-take approriate action
    ifholdout=0;
    set(handles.c,'Enable','off');
    set(handles.reptime,'Enable','off');
end
% Hint: get(hObject,'Value') returns toggle state of repeatholdout


% --- Executes on button press in permutation.
function permutation_Callback(hObject, eventdata, handles)
% hObject    handle to permutation (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global ifperm;
if (get(hObject,'Value') == get(hObject,'Max'))
    % then radio button is selected-take approriate action
    ifperm=1;
    set(handles.c1,'Enable','on');
    set(handles.reptime1,'Enable','on');
else
    % radio button is not selected-take approriate action
    ifperm=0;
    set(handles.c1,'Enable','off');
    set(handles.reptime1,'Enable','off');
end
% Hint: get(hObject,'Value') returns toggle state of permutation


% --- Executes on button press in saveset.
function saveset_Callback(hObject, eventdata, handles)
% hObject    handle to saveset (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global pre ifflag cvfold treenum;
global ifholdout ifperm ifroc c c1 reptime reptime1; 
displaystr=zeros(5,1);
ifsave=1;
errorstr=[{'Must select at least one classifier!'}...
    {'CV fold must be integer between 1 and 10 !'}...
    {'Trees of RF must be integer between 100 and 200 !'}...
    {'% for test must be between 1-50 !'}...
    {'Repeat times must be integer smaller than RF tree number minus 50 !'}];
if(get(handles.UV,'Value') == 1)
    pre=1;
elseif(get(handles.par,'Value') == 1)
    pre=2;
elseif(get(handles.Centering,'Value') == 1)
    pre=3;
end
ifpls=get(handles.plsprocess,'Value');
ifsvm=get(handles.svmprocess,'Value');
iflda=get(handles.ldaprocess,'Value');
ifrf=get(handles.rfprocess,'Value');
ifflag=[ifpls ifsvm iflda ifrf];
if(isempty(find(ifflag,1)))
    displaystr(1)=1;
    ifflag=[1 1 1 1];
    ifsave=0;
end
cvfold=str2num(get(handles.cv,'string'));
if(cvfold>10||cvfold<1)
	cvfold=10;
	displaystr(2)=1;
	ifsave=0;
end
treenum=str2num(get(handles.treenum,'string'));	
if(treenum>200||treenum<100)
	treenum=200;
	displaystr(3)=1;
	ifsave=0;
end	
ifholdout=get(handles.repeatholdout,'Value');
ifperm=get(handles.permutation,'Value');
ifroc=get(handles.rocprocess,'Value');
if(ifholdout==1)
    c=str2num(get(handles.c,'string'));
    reptime=str2num(get(handles.reptime,'string'));
    if(c>50||c<1)
        c=10;
        displaystr(4)=1;
    end
    if(reptime>treenum-50)
        reptime=100;
        displaystr(5)=1;
        ifsave=0;
    end    
end
if(ifperm==1)
    c1=str2num(get(handles.c1,'string'));
    reptime1=str2num(get(handles.reptime1,'string'));
    if(c1>50||c1<1)
        c1=10;
        displaystr(4)=1;
    end
    if(reptime1>treenum-50)
        reptime1=100;
        displaystr(5)=1;
        ifsave=0;
    end    
end
if(ifsave)
    set(handles.Run,'Enable','on');
    msgbox('   Setting success��');
else
    errordlg(errorstr(displaystr),'Setting Error');
end
% --- Executes on button press in defaultset.
function defaultset_Callback(hObject, eventdata, handles)
% hObject    handle to defaultset (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global pre ifflag cvfold treenum;
global ifholdout ifperm ifroc c c1 reptime reptime1; 
pre=1;ifflag=[1 1 1 1];cvfold=10;treenum=200;
ifholdout=0;ifperm=0;ifroc=0;c=10;c1=10;reptime=100;reptime1=100;
set(handles.UV,'Value',1);
set(handles.par,'Value',0);
set(handles.Centering,'Value',0);
set(handles.plsprocess,'Value',1);
set(handles.svmprocess,'Value',1);
set(handles.ldaprocess,'Value',1);
set(handles.rfprocess,'Value',1);
set(handles.cv,'string','10');
set(handles.treenum,'string','200');
set(handles.repeatholdout,'Value',0);
set(handles.permutation,'Value',0);
set(handles.rocprocess,'Value',0);
set(handles.c,'Enable','off');
set(handles.reptime,'Enable','off');
set(handles.c,'string',10);
set(handles.reptime,'string',100);
set(handles.c1,'Enable','off');
set(handles.reptime1,'Enable','off');
set(handles.c1,'string',10);
set(handles.reptime1,'string',100);

function err=plsholdout(sample,k,c,perm)
%% ---------- PLS permutation ------------
err=zeros(perm,1);
%---------- pls ------------   
fprintf(' The PLS is modeling.\n');
fprintf('  Percentage(test samples): %g  \n\n',c);
%% ---------- CV ------------
for permu=1:perm
    [train, test] = crossvalind('HoldOut', k, c);
	p=sample(train,:);
	t=k(train);
	ptest=sample(test,:);        
 	[Xloadings,Yloadings,Xscores,Yscores, ...
                    beta,pctVar,mse,stats] = plsregress(p,t,3);
	XscoresTest = ptest * stats.W;
	[CC,err1,P,logp,coeff] = classify(XscoresTest,Xscores,...
                    k(train),'diaglinear'); 
	co=coeff(1,2);
	linear=co.linear;
	const=co.const;
	samplescore=XscoresTest*linear+const;
	cls=ones(size(ptest,1),1);
	cls(samplescore<0)=2;
	cp=classperf(k(test),cls,'Positive',2,'Negative',1);
	errrate=cp.LastErrorRate; 
	err(permu)=errrate;
end

function [roct,area]=rocroc(score,y)
minl=min(score);
maxl=max(score);
deta=(maxl-minl)/1000;
thresh=minl-deta*10:deta:maxl+deta*10;
spec=zeros(length(thresh),1);
sens=zeros(length(thresh),1);
for j =1:length(thresh)
	cls=ones(length(score),1);
	cls((score<thresh(j)))=2;
	cp=classperf(y,cls,'Positive',2, 'Negative', 1); 
	spec(j)=cp.Specificity;
	sens(j)=cp.Sensitivity;
end
%---------- compute the area under roc ------------
%    area=sum((y(i)+y(i+1))*(x(i+1)-x(i))/2)                   
%--------------------------------------------------
yplot=sens;
xplot=1-spec;
area=trapz(xplot,yplot);
roct=[xplot yplot];
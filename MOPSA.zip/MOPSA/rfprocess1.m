function [samplescore,varscore,err] = rfprocess1(sample,k,treenum)
fprintf(' The RF is modeling.\n');
%% ----------- Random Forest ---------- %%
b = TreeBagger(treenum,sample,k,'oobvarimp','on','minleaf',10)
%% ----------- error rate curve ---------- %%
err=oobError(b);
%% ----------- variable importance ---------- %%
figure(4);
bar(b.OOBPermutedVarDeltaError);
xlabel('Feature Number');
ylabel('Out-Of-Bag Feature Importance');
varscore=b.OOBPermutedVarDeltaError;
%% ----------- class ---------- %%
b = fillProximities(b);
[ss,e] = mdsProx(b,'colors','rb');
samplescore=ss(:,1);
%% ----------- error table ---------- %%
fprintf(' error rate = %g\n',err(end));
%% ----------- roc ---------- %%
[Yfit,Sfit] = oobPredict(b);
%% ---------------------- score ������� --------------------
e1=find(k==1);
e2=find(k==2);
d1=(samplescore(e1)-mean(samplescore(e1))).^2;
d2=(samplescore(e2)-mean(samplescore(e2))).^2;
d = sum([d1;d2]);
dj=sum(([mean(samplescore(e1));mean(samplescore(e2))]-mean(samplescore)).^2);
f=dj/(d/(length(k)-2));
fprintf(' F = %g \n\n',f);
varscore=varscore';
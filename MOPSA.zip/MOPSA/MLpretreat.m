function sample = MLpretreat(pre,X)
%% ---------- scale UV ------------
if(pre==1)
    sd=repmat(std(X,0,1),size(X,1),1);
    sd(sd==0)=1;
    sample=(X-repmat(mean(X,1),size(X,1),1))./sd;
elseif(pre==2)
    sd=repmat(std(X,0,1),size(X,1),1);
    sd(sd==0)=1;
    sample=(X-repmat(mean(X,1),size(X,1),1))./sqrt(sd);
elseif(pre==3)
    sample=X-repmat(mean(X,1),size(X,1),1);   
end
function [samplescore,vip] = plsprocess(sample,k,cvn)
fprintf(' The PLS is modeling.\n');
[Xloadings,Yloadings,Xscores,Yscores, ...
                    beta,pctVar,mse,stats] = plsregress(sample,k,3,'cv',cvn);
[CC,err,P,logp,coeff] = classify(Xscores,Xscores,k,'diaglinear'); 
co=coeff(1,2);
linear=co.linear;
const=co.const;
samplescore=Xscores*linear+const;
% ---------- VIP ------------
w=stats.W(:,1);
vip=(w.^2*length(k)).^0.5;
%% ---------- error rate ------------
cls=ones(length(k),1);
cls(samplescore<0)=2;
cp=classperf(k,cls,'Positive',2,'Negative',1);
err=cp.LastErrorRate; 
fprintf(' error rate = %g\n',err);
%% ---------------------- score ������� --------------------
e1=find(k==1);
e2=find(k==2);
samscore=samplescore;
d1=(samscore(e1)-mean(samscore(e1))).^2;
d2=(samscore(e2)-mean(samscore(e2))).^2;
d = sum([d1;d2]);
dj=sum(([mean(samscore(e1));mean(samscore(e2))]-mean(samscore)).^2);
f=dj/(d/(length(k)-2));
fprintf(' F = %g \n\n',f);
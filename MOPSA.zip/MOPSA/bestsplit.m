function [err,bsplit] = bestsplit(score,y)

minl=min(score);
maxl=max(score);
bc=(maxl-minl)/length(y);
thresh=minl-bc:bc:maxl+bc;
errrate=zeros(length(thresh),1);
for i =1:length(thresh)
   cls=ones(length(score),1);
   cls((score<thresh(i)))=2;
   cp=classperf(y,cls,'Positive',2,'Negative',1);
   errrate(i)=cp.LastErrorRate; 
end
[err] = min(errrate);
ii=find(errrate==err);
bsplit=thresh(round(median(ii)));

function plotroc(ifflag,mlroc,mlarea)
mlstr=[{'PLS'} {'SVM'} {'LDA'} {'RF'}];
ifplot=find(ifflag);
for i=1:length(ifplot)
    subplot(1,length(ifplot),i)    
    plot(mlroc(:,ifplot(i)*2-1),mlroc(:,ifplot(i)*2));
    hold on
    str=strcat(mlstr(ifplot(i)));
    ttext=strcat(str,{' AUC='}, num2str(mlarea(ifplot(i))));
    title(ttext);
    xlabel('1-specificity');
    ylabel('sensitivity');
    xlim([0 1]);ylim([0 1.1]);
end

function err=svmholdout(sample,k,c,perm)
%% ---------- svm permutation ------------
err=zeros(perm,1);
%---------- SVM ------------   
fprintf(' The SVM is modeling.\n');
fprintf('  Percentage(test samples): %g\n\n',c);
for permu=1:perm
%---------- choose samples for trainning ------------
	[train, test] = crossvalind('HoldOut', k, c);
    p=sample(train,:);
	t=k(train);
	ptest=sample(test,:);
	svmStruct = svmtrain(p,t);
	[classified,Y] = svmdecision(ptest,svmStruct);
% ================== bestsplit ===================
	output1 = svmclassify1(svmStruct,p);
	[errrate,bsplit] = bestsplit(output1.sampleOrig,t);
    [errrate] = errorrate(Y,bsplit,k(test));
% ================================================    
%---------- compute the error rate ------------
	err(permu)=errrate;
end
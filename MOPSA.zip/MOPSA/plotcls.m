function plotcls(ifflag,samplescore,k)
mlstr=[{'PLS'} {'SVM'} {'LDA'} {'RF'}];
sam=1:size(samplescore,1);
px=-9:length(sam)+10;
ii=randperm(length(sam));
samplescore=samplescore(ii,:);
k=k(ii,:);
ifplot=find(ifflag);
e1=k==1;
e2=k==2;
for i=1:length(ifplot)
    subplot(1,length(ifplot),i)   
    plot(sam(e1),samplescore(e1,ifplot(i)),'r.',sam(e2),...
                    samplescore(e2,ifplot(i)),'b.');
    hold on
    str=strcat(mlstr(ifplot(i)));
    title(str);
    plot(px,zeros(1,length(px)),'k');
    xlim([-9 length(sam)+10]);
end

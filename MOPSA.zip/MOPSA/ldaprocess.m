function [samplescore,varcv] = ldaprocess(sample,k,cvn)
fprintf(' The LDA is modeling.\n');
% ---------- cross validation ------------
ind= crossvalind('Kfold',k,cvn);
cp = classperf(k,'Positive', 2, 'Negative', 1); 
%% ----------------- lda cv ---------------
linear=zeros(size(sample,2),cvn);
samplescore=zeros(1,length(k));
for cv=1:cvn 
   [C,err,P,logp,coeff] = classify(sample((ind==cv),:),sample(ind~=cv,:),k(ind~=cv),'diaglinear'); 
   classperf(cp,C,(ind==cv));
   co=coeff(1,2);
   linear(:,cv)=co.linear;
   const=co.const;
   samplescore(ind==cv)=sample((ind==cv),:)*co.linear+const;
end
varcv=mean(linear,2);
samplescore=samplescore';
% linearrsd=std(linear,0,2)./varcv;
%% ----------------- error table ------------------
C=zeros(size(k));
C(samplescore>0)=1;
C(samplescore<0)=2;
cp=classperf(k,C,'Positive', 2, 'Negative', 1); 
% errtab=cp.DiagnosticTable;
err=cp.ErrorRate;
% tnt=errtab(2,2);fnt=errtab(2,1);tpt=errtab(1,1);fpt=errtab(1,2);
% fprintf('             |    expect1   |    expect2 \n');
% fprintf('-------------|--------------|------------ \n');
% fprintf(' classified1 |     %g       |     %g   \n',tnt,fnt);
% fprintf(' classified2 |     %g       |     %g   \n',fpt,tpt);
fprintf(' error rate = %g\n',err);

e1=find(k==1);
e2=find(k==2);
%% ---------------------- score ������� --------------------
d1=(samplescore(e1)-mean(samplescore(e1))).^2;
d2=(samplescore(e2)-mean(samplescore(e2))).^2;
d = sum([d1;d2]);
dj=sum(([mean(samplescore(e1));mean(samplescore(e2))]-mean(samplescore)).^2);
f=dj/(d/(length(k)-2));
fprintf(' F = %g \n\n',f);

function ploterr(ifflag,mlerr)
mlstr=[{'PLS'} {'SVM'} {'LDA'} {'RF'}];
reptime=size(mlerr,1);
ifplot=find(ifflag);
for i=1:length(ifplot)
    subplot(1,length(ifplot),i)   
    plot(1:100,mlerr(1:reptime,ifplot(i)));
    hold on
    str=strcat(mlstr(ifplot(i)));
    title(str);
    ylabel('error rate');
    plot(1:reptime,ones(1,reptime)*0.5,'k');
    xlim([1 reptime]);ylim([0 1]);
end
function [samscore,varcv] = svmprocess(sample,k,cvn)
fprintf(' The SVM is modeling.\n');
% ---------- cross validation ------------
ind= crossvalind('Kfold',k,cvn);
%% ----------- svm cv ---------- %%
yscore=zeros(length(k),1);
varscore=zeros(size(sample,2),cvn);
for cv=1:cvn
    train=ind~=cv;
    test=ind==cv;
    svmStruct = svmtrain(sample(train,:),k(train));
% ================== bestsplit ===================
    output1 = svmclassify1(svmStruct,sample(train,:));
    [err,bsplit] = bestsplit(output1.sampleOrig,k(train));
% ================================================    
    sv = svmStruct.SupportVectors;
    alphaHat = svmStruct.Alpha;
    svIndex=svmStruct.SupportVectorIndices;
    output = svmclassify1(svmStruct,sample(test,:));
    Y=output.sampleOrig;
%     classperf(cp,output.classified,test);
    svlabel = k(svIndex);
    %calculate w
    w=sv'*(svlabel.*alphaHat);
    %calculate c
    c1=mean(sv(svlabel==1,:),1);
    c2=mean(sv(svlabel==2,:),1);
    c=c1-c2;
    %calcuate value
    resvalue = abs(c') .* w;
    yscore(test)=Y;
    varscore(:,cv)=resvalue;
end
samscore=yscore;
varcv=mean(varscore,2);
%% ------------------ error table ----------------------
[err] = errorrate(samscore,bsplit,k);
fprintf(' error rate = %g\n',err);
e1=find(k==1);
e2=find(k==2);
%% ---------------------- score ������� --------------------
d1=(samscore(e1)-mean(samscore(e1))).^2;
d2=(samscore(e2)-mean(samscore(e2))).^2;
d = sum([d1;d2]);
dj=sum(([mean(samscore(e1));mean(samscore(e2))]-mean(samscore)).^2);
f=dj/(d/(length(k)-2));
fprintf(' F = %g \n\n',f);
